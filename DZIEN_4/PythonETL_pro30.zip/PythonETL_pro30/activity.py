from __future__ import annotations

from dataclasses import dataclass
import datetime as _dt

from etl_errors import ValidationError


@dataclass(frozen=True, slots=True)
class Activity:
    """Jedna aktywność treningowa.

    Format wejściowy:
        date|athlete|type|distance_km|time_min
    """
    date: _dt.date
    athlete: str
    type: str
    distance_km: float
    time_min: float

    def __post_init__(self) -> None:
        athlete = (self.athlete or "").strip()
        if not athlete:
            raise ValidationError("athlete nie może być pusty")
        object.__setattr__(self, "athlete", athlete)

        t = (self.type or "").strip().lower()
        if not t:
            raise ValidationError("type nie może być pusty")
        object.__setattr__(self, "type", t)

        if self.distance_km <= 0:
            raise ValidationError("distance_km musi być > 0")
        if self.time_min <= 0:
            raise ValidationError("time_min musi być > 0")

    @property
    def pace_min_per_km(self) -> float:
        return self.time_min / self.distance_km
