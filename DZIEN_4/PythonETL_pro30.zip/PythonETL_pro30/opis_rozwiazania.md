# Opis rozwiązania – Mini ETL PRO (Zadanie 2)

Ten projekt realizuje wymagania z PDF "Zadanie 2 – Mini ETL PRO" fileciteturn0file0.

## A. Abstrakcja źródła danych
- `sources.py`
  - `ActivitySource` (ABC) z metodą `read_lines() -> Iterator[str]`
  - `TextFileSource(path)` czyta linie z pliku (owija błędy jako `SourceError`)
  - `InMemorySource(lines)` do testów

## B. Metody klasowe (fabryka)
- `training_log.py`
  - `TrainingLog.from_source(source, strict=False)`:
    - iteruje po `source.read_lines()`
    - parsuje linie do `Activity`
    - zwraca `(TrainingLog, ETLReport)`

Tryby:
- `strict=False`: błędne linie są pomijane, logowane jako WARNING i zapisywane w raporcie.
- `strict=True`: pierwszy błąd parsowania/walidacji przerywa działanie (wyjątek domenowy).

## C. Logowanie
- `logging_config.py`
  - `LoggingConfig` (dataclass)
  - `configure_logging(config)`:
    - zawsze log na konsolę
    - opcjonalny log do pliku
    - opcjonalna rotacja logów (`RotatingFileHandler`)

## D. Obsługa błędów
- `etl_errors.py`
  - `ETLError` + `ParseError`, `SourceError`, `ValidationError`
- `pipeline.py`
  - `parse_activity_line()` podnosi `ParseError` dla złego formatu i `ValidationError` dla złych wartości (walidacje są w `Activity.__post_init__`)

## E. Raport ETL
- `reporting.py`
  - `ETLReport` z polami wymaganymi w zadaniu
  - `errors[]` jako lista wpisów `{line_no, line, error_type, message}`
- `main.py` zapisuje raport do JSON po zakończeniu przetwarzania

## F. Struktura
Zachowana struktura rekomendowana w PDF:
- `activity.py`
- `sources.py`
- `etl_errors.py`
- `logging_config.py`
- `pipeline.py`
- `training_log.py`
- `reporting.py`
- `main.py`

## Szybki test
W katalogu `mini_etl_pro/` jest `data/trainings.txt` z kilkoma celowo błędnymi liniami,
żeby było widać różnicę strict vs non-strict.
