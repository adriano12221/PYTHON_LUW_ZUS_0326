from __future__ import annotations

class ETLError(Exception):
    """Bazowy wyjątek dla całego pipeline ETL."""


class ParseError(ETLError):
    """Błąd formatu linii wejściowej."""


class SourceError(ETLError):
    """Błąd odczytu danych ze źródła."""


class ValidationError(ETLError):
    """Błąd walidacji wartości po parsowaniu."""
