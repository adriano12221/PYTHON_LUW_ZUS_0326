from __future__ import annotations

import logging
from typing import Iterable, List, Optional, Dict

from activity import Activity
from etl_errors import ETLError, ParseError, SourceError, ValidationError
from sources import ActivitySource
from pipeline import parse_activity_line
from reporting import ETLReport, ErrorEntry

log = logging.getLogger(__name__)


class TrainingLog:
    """Dziennik treningów (produkcyjny wariant) + statystyki."""

    def __init__(self, activities: Iterable[Activity]) -> None:
        self._activities: List[Activity] = list(activities)
        self._cache_distance: Dict[Optional[str], float] = {}
        self._cache_time: Dict[Optional[str], float] = {}

    @property
    def activities(self) -> List[Activity]:
        return list(self._activities)

    def total_distance(self, typ: Optional[str] = None) -> float:
        key = None if typ is None else (typ.strip().lower())
        if key in self._cache_distance:
            return self._cache_distance[key]

        total = 0.0
        for a in self._activities:
            if key is None or a.type == key:
                total += a.distance_km

        self._cache_distance[key] = total
        return total

    def total_time(self, typ: Optional[str] = None) -> float:
        key = None if typ is None else (typ.strip().lower())
        if key in self._cache_time:
            return self._cache_time[key]

        total = 0.0
        for a in self._activities:
            if key is None or a.type == key:
                total += a.time_min

        self._cache_time[key] = total
        return total

    @property
    def summary(self) -> str:
        total_km = self.total_distance()
        total_min = self.total_time()
        pace = (total_min / total_km) if total_km else 0.0
        return f"Rekordów: {len(self._activities)} | Dystans: {total_km:.2f} km | Czas: {total_min:.1f} min | Śr. tempo: {pace:.2f} min/km"

    @classmethod
    def from_source(cls, source: ActivitySource, *, strict: bool = False):
        """Fabryka: buduje TrainingLog na podstawie ActivitySource.

        strict=False:
          - błędne linie pomijane
          - błędy logowane
        strict=True:
          - przerwanie przy pierwszym błędzie
        Zwraca: (TrainingLog, ETLReport)
        """


        """
        func(a,b,*args,br,**kwargs)
         -> args[0], args[1]   - jeśli *args
        func(a,b,*,c,d)
        
        u = func(1,2,c=3,d=4)
        
        def from_source(cls, source: ActivitySource, *, g, strict: bool = False):
        -> strict nie muszę definiować ,ale jeśli to jawnie strict = ... , 
        g muszę deklarować i tylko jawnie np. g=9
        
        """
        import datetime as _dt

        started = _dt.datetime.now(_dt.timezone.utc)
        activities: List[Activity] = []
        errors: List[ErrorEntry] = []
        processed = 0

        try:
            for i, line in enumerate(source.read_lines(), start=1):
                processed += 1
                if not (line or "").strip():
                    # pusta linia traktujemy jak błąd formatu
                    err = ParseError("Pusta linia")
                    if strict:
                        raise err
                    log.warning("Pomijam pustą linię %s", i)
                    errors.append(ErrorEntry(i, line, type(err).__name__, str(err)))
                    continue

                try:
                    act = parse_activity_line(line)
                    activities.append(act)
                except (ParseError, ValidationError) as e:
                    if strict:
                        raise
                    log.warning("Pomijam linię %s: %s | %s", i, line, e)
                    errors.append(ErrorEntry(i, line, type(e).__name__, str(e)))

        except SourceError:
            # SourceError ma być domenowy i niech idzie wyżej
            raise
        except ETLError:
            # ParseError/ValidationError w strict
            raise
        except OSError as e:
            raise SourceError("Błąd IO podczas czytania źródła") from e

        finished = _dt.datetime.now(_dt.timezone.utc)
        report = ETLReport(
            started_at=started.isoformat(),
            finished_at=finished.isoformat(),
            source=source.__class__.__name__,
            strict=strict,
            processed_lines=processed,
            accepted_records=len(activities),
            rejected_records=len(errors),
            errors=errors,
        )
        return cls(activities), report
