from __future__ import annotations

import argparse
import logging

from logging_config import LoggingConfig, configure_logging
from sources import TextFileSource
from training_log import TrainingLog
from etl_errors import ETLError, SourceError

log = logging.getLogger(__name__)

#zmiany uruchomieniu = zmiany w atrybucie default!
def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Mini ETL PRO: treningi (logowanie, abstrakcja, błędy, raport)")
    p.add_argument("--input", "-i", default="data/trainings.txt", help="Ścieżka do pliku wejściowego TXT")
    p.add_argument("--strict", action="store_true", help="Przerwij przy pierwszym błędzie (strict=True)")
    p.add_argument("--report", "-r", default="etl_report.json", help="Ścieżka do raportu JSON")
    p.add_argument("--loglevel", default="INFO", help="DEBUG/INFO/WARNING/ERROR")
    p.add_argument("--logfile", default="etl.log", help="Ścieżka do pliku logów (jeśli --tofile)")
    p.add_argument("--tofile", action="store_true", help="Zapisuj logi do pliku")
    p.add_argument("--rotate", action="store_true", help="Rotacja logów")
    return p


def main() -> int:
    args = build_arg_parser().parse_args()

    configure_logging(
        LoggingConfig(
            level=args.loglevel,
            to_file=args.tofile,
            log_file=args.logfile,
            rotate=args.rotate,
        )
    )

    try:
        source = TextFileSource(args.input)
        log.info("Start ETL | input=%s | strict=%s", args.input, args.strict)

        logbook, report = TrainingLog.from_source(source, strict=args.strict)

        log.info(logbook.summary)
        report.save_json(args.report)
        log.info("Raport zapisany: %s", args.report)
        return 0

    except SourceError as e:
        log.error("Błąd źródła: %s", e)
        return 2
    except ETLError as e:
        log.error("Błąd ETL: %s", e)
        return 3
    except Exception as e:
        log.exception("Nieoczekiwany błąd: %s", e)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
