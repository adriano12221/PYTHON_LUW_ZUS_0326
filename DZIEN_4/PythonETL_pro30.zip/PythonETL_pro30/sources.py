from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Iterator, Iterable, List

from etl_errors import SourceError


class ActivitySource(ABC):
    """Abstrakcja źródła danych."""

    @abstractmethod
    def read_lines(self) -> Iterator[str]:
        raise NotImplementedError


@dataclass(frozen=True, slots=True)
class TextFileSource(ActivitySource):
    path: str

    def read_lines(self) -> Iterator[str]:
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                for line in f:
                    yield line.rstrip("\n")
        except OSError as e:
            raise SourceError(f"Nie można odczytać pliku: {self.path}") from e


@dataclass(frozen=True, slots=True)
class InMemorySource(ActivitySource):
    lines: List[str]

    def read_lines(self) -> Iterator[str]:
        # do testów, więc tu nie podnosimy SourceError
        for line in self.lines:
            yield line
