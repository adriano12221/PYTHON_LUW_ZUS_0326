from __future__ import annotations

from dataclasses import dataclass, field
import datetime as _dt
import json
from typing import Any, Dict, List, Optional


@dataclass
class ErrorEntry:
    line_no: int
    line: str
    error_type: str
    message: str


@dataclass
class ETLReport:
    started_at: str
    finished_at: str
    source: str
    strict: bool
    processed_lines: int
    accepted_records: int
    rejected_records: int
    errors: List[ErrorEntry] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "source": self.source,
            "strict": self.strict,
            "processed_lines": self.processed_lines,
            "accepted_records": self.accepted_records,
            "rejected_records": self.rejected_records,
            "errors": [
                {
                    "line_no": e.line_no,
                    "line": e.line,
                    "error_type": e.error_type,
                    "message": e.message,
                }
                for e in self.errors
            ],
        }

    def save_json(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)
