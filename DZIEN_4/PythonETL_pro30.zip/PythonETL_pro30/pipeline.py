from __future__ import annotations

import datetime as _dt
import logging
from typing import Iterable, Iterator, Optional

from activity import Activity
from etl_errors import ParseError, ValidationError

log = logging.getLogger(__name__)


def parse_activity_line(line: str) -> Activity:
    """Parser pojedynczej linii.

    Rzuca:
    - ParseError (zły format)
    - ValidationError (złe wartości)
    """
    parts = [p.strip() for p in (line or "").split("|")]
    if len(parts) != 5:
        raise ParseError(f"Linia powinna mieć 5 pól rozdzielonych |, ma: {len(parts)}")

    date_s, athlete, typ, dist_s, time_s = parts

    try:
        date = _dt.date.fromisoformat(date_s)
    except ValueError as e:
        raise ParseError(f"Niepoprawna data ISO: {date_s}") from e

    try:
        dist = float(dist_s)
        time = float(time_s)
    except ValueError as e:
        raise ParseError("distance_km i time_min muszą być liczbami") from e

    return Activity(date=date, athlete=athlete, type=typ, distance_km=dist, time_min=time)


def only_type(activities: Iterable[Activity], typ: str) -> Iterator[Activity]:
    t = (typ or "").strip().lower()
    for a in activities:
        if a.type == t:
            yield a


def only_athlete(activities: Iterable[Activity], athlete: str) -> Iterator[Activity]:
    name = (athlete or "").strip()
    for a in activities:
        if a.athlete == name:
            yield a
