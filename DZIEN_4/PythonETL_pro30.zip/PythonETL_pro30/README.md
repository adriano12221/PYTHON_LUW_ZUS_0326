# Mini ETL PRO – Treningi

Projekt zbudowany na bazie "Mini ETL" (wersja pierwotna w katalogu `../original_solution/`),
rozszerzony o elementy produkcyjne:
- abstrakcja źródeł (`ActivitySource`, `TextFileSource`, `InMemorySource`)
- metoda klasowa `TrainingLog.from_source(...)` (fabryka)
- logowanie konfigurowalne (`LoggingConfig`, `configure_logging`)
- błędy domenowe (`ETLError`, `ParseError`, `SourceError`, `ValidationError`)
- raport JSON z przebiegu ETL (`ETLReport`)

## Format danych
`date|athlete|type|distance_km|time_min`

Przykład:
`2026-03-01|Marcin|run|12.5|65`

## Uruchomienie
Z katalogu `mini_etl_pro/`:

```bash
python main.py --input data/trainings.txt --report etl_report.json
python main.py --input data/trainings.txt --strict --loglevel DEBUG
python main.py --input data/trainings.txt --tofile --logfile etl.log --rotate
```

W trybie non-strict błędne linie są pomijane i trafiają do raportu.
W trybie strict program przerywa pracę przy pierwszym błędzie.
