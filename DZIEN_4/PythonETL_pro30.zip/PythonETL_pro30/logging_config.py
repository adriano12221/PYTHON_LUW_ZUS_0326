from __future__ import annotations

from dataclasses import dataclass
import logging
from logging.handlers import RotatingFileHandler
from typing import Optional


@dataclass(frozen=True, slots=True)
class LoggingConfig:
    level: str = "INFO"           # DEBUG / INFO / WARNING / ERROR
    to_file: bool = False
    log_file: str = "etl.log"
    rotate: bool = False
    max_bytes: int = 1_000_000
    backup_count: int = 3


def configure_logging(config: LoggingConfig) -> None:
    """Konfiguracja logowania dla aplikacji.

    Wymagania z zadania:
    - logi na konsoli
    - opcjonalnie logi do pliku
    - poziomy DEBUG / INFO / WARNING / ERROR
    """
    level = getattr(logging, config.level.upper(), logging.INFO)

    logger = logging.getLogger()
    logger.handlers.clear()
    logger.setLevel(level)

    fmt = logging.Formatter(
        fmt="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    console = logging.StreamHandler()
    console.setLevel(level)
    console.setFormatter(fmt)
    logger.addHandler(console)

    if config.to_file:
        if config.rotate:
            handler = RotatingFileHandler(
                config.log_file,
                maxBytes=config.max_bytes,
                backupCount=config.backup_count,
                encoding="utf-8",
            )
        else:
            handler = logging.FileHandler(config.log_file, encoding="utf-8")
        handler.setLevel(level)
        handler.setFormatter(fmt)
        logger.addHandler(handler)
