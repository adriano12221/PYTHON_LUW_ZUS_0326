from __future__ import annotations

from meta import WriterMeta
import writers  # noqa: F401  (import rejestruje klasy writerów)


def demo() -> None:
    # 1) CSV: lista słowników o tych samych kluczach i skalarnych wartościach
    data_csv = [
        {"date": "2026-03-01", "athlete": "Marcin", "activity": "run", "distance_km": 10.0, "time_min": 45},
        {"date": "2026-03-02", "athlete": "Ewa", "activity": "run", "distance_km": 5.0, "time_min": 28},
    ]

    # 2) XML: dict z jednym root-tag
    data_xml = {
        "person": {
            "name": "Marcin",
            "age": 53,
            "skills": ["Python", "AI", "ETL"],
            "meta": {"role": "trainer", "level": "pro"}
        }
    }

    # 3) JSON: fallback
    data_json = {
        "project": "ANIMA",
        "notes": ["resonance", "pipeline", "field"],
        "metrics": {"itrapoints": 421, "goal": 500}
    }

    for i, (data, out) in enumerate(
        [(data_csv, "out.csv"), (data_xml, "out.xml"), (data_json, "out.json")],
        start=1
    ):
        writer = WriterMeta.create_for(data)
        print(f"[{i}] inferred={writer.format_name} -> saving {out}")
        writer.save(out)

    print("\nDone. Files generated: out.csv, out.xml, out.json")


if __name__ == "__main__":
    demo()
