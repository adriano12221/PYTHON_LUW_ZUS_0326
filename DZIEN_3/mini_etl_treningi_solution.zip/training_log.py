from __future__ import annotations

from typing import Iterable, Optional, List, Dict, Tuple
import json
from activity import Activity


class TrainingLog:
    """Prosty dziennik treningów z metodami agregacji + cache (hard mode)."""

    def __init__(self, activities: Iterable[Activity]) -> None:
        self._activities: List[Activity] = list(activities)
        self._cache_distance: Dict[Optional[str], float] = {}
        self._cache_time: Dict[Optional[str], float] = {}

    @property
    def activities(self) -> List[Activity]:
        # zwracamy kopię, żeby nie psuć cache "z zewnątrz"
        return list(self._activities)

    def total_distance(self, type: Optional[str] = None) -> float:
        key = None if type is None else (type.strip().lower())
        if key in self._cache_distance:
            return self._cache_distance[key]
        total = 0.0
        for a in self._activities:
            if key is None or a.type == key:
                total += a.distance_km
        self._cache_distance[key] = total
        return total

    def total_time(self, type: Optional[str] = None) -> float:
        key = None if type is None else (type.strip().lower())
        if key in self._cache_time:
            return self._cache_time[key]
        total = 0.0
        for a in self._activities:
            if key is None or a.type == key:
                total += a.time_min
        self._cache_time[key] = total
        return total

    def best_pace(self) -> Optional[Tuple[float, Activity]]:
        """Najlepsze (najniższe) tempo dla run. Zwraca (pace, aktywność) lub None."""
        best = None
        best_act = None
        for a in self._activities:
            p = a.pace_min_per_km
            if p is None:
                continue
            if best is None or p < best:
                best = p
                best_act = a
        if best is None:
            return None
        return best, best_act  # type: ignore[return-value]

    def long_runs(self) -> List[Activity]:
        return [a for a in self._activities if a.type == "run" and a.is_long]

    @property
    def summary(self) -> str:
        total_km = self.total_distance()
        total_min = self.total_time()
        runs_km = self.total_distance("run")
        bike_km = self.total_distance("bike")
        best = self.best_pace()
        if best:
            pace, act = best
            best_line = (
                f"Najlepsze tempo (run): {pace:.2f} min/km "
                f"({act.date.isoformat()}, {act.athlete}, {act.distance_km:g} km)"
            )
        else:
            best_line = "Najlepsze tempo (run): brak danych"

        long_count = len(self.long_runs())
        return (
            "=== TrainingLog Summary ===\n"
            f"Liczba wpisów: {len(self._activities)}\n"
            f"Suma dystansu: {total_km:.2f} km\n"
            f"Suma czasu: {total_min:.0f} min\n"
            f"Dystans run: {runs_km:.2f} km\n"
            f"Dystans bike: {bike_km:.2f} km\n"
            f"Długie biegi (>=20 km): {long_count}\n"
            f"{best_line}\n"
        )

    def to_json(self, path: str) -> None:
        payload = [a.to_dict() for a in self._activities]
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)

    @staticmethod
    def from_json(path: str) -> "TrainingLog":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        acts = [Activity.from_dict(d) for d in data]
        return TrainingLog(acts)
