from __future__ import annotations

import datetime as _dt
from typing import Iterable, Iterator, Optional
from activity import Activity


def source_lines(lines: Optional[Iterable[str]] = None) -> Iterator[str]:
    """Źródło linii: iteruje po przekazanych liniach lub po wbudowanym przykładzie."""
    if lines is None:
        example = [
            "2026-03-01|Marcin|run|12.5|65",
            "2026-03-02|Marcin|run|8.0|44",
            "2026-03-02|Ewa|bike|30.0|75",
            "2026-03-03|Marcin|run|21.1|110",
            "BAD|LINE",
            "2026-03-03|Ewa|run|5.0|33",
        ]
        yield from example
    else:
        for line in lines:
            yield line


def parse(lines: Iterable[str]) -> Iterator[Activity]:
    """Parser: zamienia linie na Activity, a błędne linie pomija (silent skip)."""
    for raw in lines:
        try:
            raw = raw.strip()
            if not raw:
                continue
            parts = raw.split("|")
            if len(parts) != 5:
                raise ValueError("zła liczba pól")
            date_s, athlete, typ, dist_s, time_s = parts
            date = _dt.date.fromisoformat(date_s.strip())
            dist = float(dist_s)
            tmin = float(time_s)
            yield Activity(
                date=date,
                athlete=athlete.strip(),
                type=typ,
                distance_km=dist,
                time_min=tmin,
            )
        except Exception:
            # wymaganie: pomija błędne linie
            continue


def only_type(activities: Iterable[Activity], wanted_type: str) -> Iterator[Activity]:
    wt = (wanted_type or "").strip().lower()
    for a in activities:
        if a.type == wt:
            yield a


def only_athlete(activities: Iterable[Activity], athlete: str) -> Iterator[Activity]:
    who = (athlete or "").strip()
    for a in activities:
        if a.athlete == who:
            yield a
