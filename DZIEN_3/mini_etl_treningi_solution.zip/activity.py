from __future__ import annotations

from dataclasses import dataclass
import datetime as _dt
from typing import Optional


@dataclass(frozen=True, slots=True)
class Activity:
    """Jedna aktywność treningowa.

    Wejściowy format linii:
        date|athlete|type|distance_km|time_min
    """
    date: _dt.date
    athlete: str
    type: str
    distance_km: float
    time_min: float

    def __post_init__(self) -> None:
        # Normalizacja type
        t = (self.type or "").strip().lower()
        object.__setattr__(self, "type", t)

        # Walidacje
        if not (self.athlete and self.athlete.strip()):
            raise ValueError("athlete nie może być pusty")
        if self.distance_km <= 0:
            raise ValueError("distance_km musi być > 0")
        if self.time_min <= 0:
            raise ValueError("time_min musi być > 0")

    @property
    def pace_min_per_km(self) -> Optional[float]:
        """Tempo min/km (tylko dla 'run'), w przeciwnym razie None."""
        if self.type != "run":
            return None
        return self.time_min / self.distance_km

    @property
    def speed_km_per_h(self) -> float:
        """Prędkość km/h (dla dowolnego typu aktywności)."""
        hours = self.time_min / 60.0
        return self.distance_km / hours

    @property
    def is_long(self) -> bool:
        """Długi trening: True jeśli distance_km >= 20."""
        return self.distance_km >= 20.0

    def to_dict(self) -> dict:
        return {
            "date": self.date.isoformat(),
            "athlete": self.athlete,
            "type": self.type,
            "distance_km": self.distance_km,
            "time_min": self.time_min,
        }

    @staticmethod
    def from_dict(d: dict) -> "Activity":
        return Activity(
            date=_dt.date.fromisoformat(d["date"]),
            athlete=d["athlete"],
            type=d["type"],
            distance_km=float(d["distance_km"]),
            time_min=float(d["time_min"]),
        )
