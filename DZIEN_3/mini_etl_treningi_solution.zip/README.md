# Mini ETL dla treningów biegowych – rozwiązanie

Pliki:
- `activity.py` – dataclass `Activity` + walidacje + properties
- `pipeline.py` – generatorowy pipeline: `source_lines`, `parse`, `only_type`, `only_athlete`
- `training_log.py` – klasa `TrainingLog` + cache + eksport/import JSON (hard mode)
- `main_demo.py` – krótki pokaz użycia

## Uruchomienie
W katalogu projektu:

python main_demo.py
