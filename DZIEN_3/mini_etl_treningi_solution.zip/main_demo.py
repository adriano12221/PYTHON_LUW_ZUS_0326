from pipeline import source_lines, parse, only_athlete, only_type
from training_log import TrainingLog


def main() -> None:
    activities = parse(source_lines())
    marcin_runs = only_type(only_athlete(activities, "Marcin"), "run")

    log = TrainingLog(marcin_runs)
    print(log.summary)

    out = "marcin_runs.json"
    log.to_json(out)
    log2 = TrainingLog.from_json(out)
    print("Odczyt z JSON OK. Wpisy:", len(log2.activities))


if __name__ == "__main__":
    main()
