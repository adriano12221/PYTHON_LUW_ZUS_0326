"""analyzers.py

Zawiera klasę bazową FileAnalyzer oraz podstawowe implementacje:
TXT, CSV, JSON, XML.
"""

from __future__ import annotations

import csv
import json
import os
import time
import xml.etree.ElementTree as ET
from abc import ABC, abstractmethod
from typing import Any

from registry import AnalyzerMeta


class FileAnalyzer(ABC, metaclass=AnalyzerMeta):
    """Abstrakcyjna klasa bazowa dla wszystkich analizatorów.

    Każdy analizator:
    - deklaruje obsługiwane rozszerzenie w polu class attribute `extension`
    - implementuje metodę analyze(file_path)

    Pole __abstract__ jest użyte przez metaklasę, aby nie próbowała
    rejestrować samej klasy bazowej jako prawdziwego pluginu.
    """

    __abstract__ = True
    extension: str | None = None

    @abstractmethod
    def analyze(self, file_path: str) -> Any:
        """Analizuje wskazany plik i zwraca wynik analizy."""

    @staticmethod
    def ensure_exists(file_path: str) -> None:
        """Pomocnicza walidacja istnienia pliku."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Plik nie istnieje: {file_path}")

    @staticmethod
    def simulate_io_delay(delay: float = 0.15) -> None:
        """Celowe opóźnienie, aby łatwiej zobaczyć zysk z wielowątkowości.

        W realnych systemach takim "opóźnieniem" jest zwykle odczyt z dysku,
        sieci lub bazy danych. Tutaj dodajemy mały sleep edukacyjnie.
        """
        time.sleep(delay)


class TXTAnalyzer(FileAnalyzer):
    """Analizator plików tekstowych.

    Zwraca liczbę słów w pliku .txt.
    """

    extension = ".txt"

    def analyze(self, file_path: str) -> int:
        self.ensure_exists(file_path)
        self.simulate_io_delay()

        with open(file_path, "r", encoding="utf-8") as file:
            content = file.read()

        # split() domyślnie rozdziela po białych znakach.
        return len(content.split())


class CSVAnalyzer(FileAnalyzer):
    """Analizator plików CSV.

    Zwraca liczbę wierszy danych.
    Jeśli plik posiada nagłówek, jest on odliczany od wyniku.
    """

    extension = ".csv"

    def analyze(self, file_path: str) -> int:
        self.ensure_exists(file_path)
        self.simulate_io_delay()

        with open(file_path, "r", encoding="utf-8", newline="") as file:
            reader = csv.reader(file)
            rows = list(reader)

        if not rows:
            return 0

        # Zakładamy, że pierwszy wiersz jest nagłówkiem.
        return max(len(rows) - 1, 0)


class JSONAnalyzer(FileAnalyzer):
    """Analizator plików JSON.

    Zwraca liczbę elementów w strukturze danych.
    Reguły:
    - lista -> liczba elementów listy
    - słownik -> liczba kluczy
    - inne typy -> 1
    """

    extension = ".json"

    def analyze(self, file_path: str) -> int:
        self.ensure_exists(file_path)
        self.simulate_io_delay()

        with open(file_path, "r", encoding="utf-8") as file:
            data = json.load(file)

        if isinstance(data, list):
            return len(data)
        if isinstance(data, dict):
            return len(data)
        return 1


class XMLAnalyzer(FileAnalyzer):
    """Analizator plików XML.

    Zwraca liczbę elementów XML, licząc wszystkie znaczniki poza korzeniem.
    """

    extension = ".xml"

    def analyze(self, file_path: str) -> int:
        self.ensure_exists(file_path)
        self.simulate_io_delay()

        tree = ET.parse(file_path)
        root = tree.getroot()

        # Iterujemy po wszystkich elementach drzewa. Korzeń pomijamy.
        return sum(1 for _ in root.iter()) - 1
