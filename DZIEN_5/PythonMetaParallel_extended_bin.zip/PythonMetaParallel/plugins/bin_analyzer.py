from __future__ import annotations
from analyzers import FileAnalyzer


class BinAnalyzer(FileAnalyzer):
    extension = ".bin"
    def analyze(self, file_path: str) -> int:
        self.ensure_exists(file_path)
        self.simulate_io_delay()

        with open(file_path, "rb") as file:
            data = file.read()
        return len(data)