"""Pakiet z dynamicznie ładowanymi pluginami analizatorów."""
