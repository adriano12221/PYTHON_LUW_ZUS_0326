"""Przykładowy plugin dynamiczny.

Ten moduł nie wymaga żadnej zmiany w kodzie głównym.
Po samym imporcie klasa rejestruje się przez metaklasę.
"""

from __future__ import annotations

from analyzers import FileAnalyzer


class LOGAnalyzer(FileAnalyzer):
    """Analizator plików .log.

    Zwraca liczbę linii w logu.
    """

    extension = ".log"

    def analyze(self, file_path: str) -> int:
        self.ensure_exists(file_path)
        self.simulate_io_delay()

        with open(file_path, "r", encoding="utf-8") as file:
            return sum(1 for _ in file)
