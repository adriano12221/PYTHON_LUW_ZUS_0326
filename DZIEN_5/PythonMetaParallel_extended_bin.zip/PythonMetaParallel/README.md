# Rozwiązanie zadania PRO: Metaklasy + concurrent.futures

Projekt realizuje wszystkie wymagania z treści zadania:

## Zrealizowane elementy

1. **Metaklasa `AnalyzerMeta`**
   - automatycznie rejestruje analizatory,
   - pilnuje obecności metody `analyze()`,
   - zapisuje klasy w globalnym rejestrze `AnalyzerRegistry`.

2. **Abstrakcyjna klasa bazowa `FileAnalyzer`**
   - stanowi wspólny kontrakt dla analizatorów,
   - wymusza implementację `analyze(file_path)`.

3. **Analizatory**
   - `TXTAnalyzer` -> liczba słów,
   - `CSVAnalyzer` -> liczba wierszy danych,
   - `JSONAnalyzer` -> liczba elementów,
   - `XMLAnalyzer` -> liczba elementów XML.

4. **Silnik analizy `engine.py`**
   - dobiera analizator po rozszerzeniu,
   - obsługuje błędy,
   - potrafi działać sekwencyjnie i równolegle.

5. **Równoległość**
   - użyto `ThreadPoolExecutor`,
   - wyniki są zbierane przez `as_completed()` w kolejności zakończenia.

6. **Wymagania PRO**
   - logowanie do pliku `analysis.log`,
   - porównanie czasu sekwencyjnego i równoległego,
   - dynamiczne ładowanie pluginów z katalogu `plugins/`,
   - dodatkowy analizator XML,
   - bonusowo: plugin `LOGAnalyzer` dla plików `.log`.

## Struktura projektu

- `registry.py` – rejestr i metaklasa,
- `analyzers.py` – klasa bazowa i główne analizatory,
- `engine.py` – silnik analizy i logowanie,
- `main.py` – uruchomienie programu,
- `plugins/` – dynamicznie ładowane pluginy,
- `data/` – przykładowe pliki wejściowe.

## Uruchomienie

```bash
python main.py
```

## Dlaczego `ThreadPoolExecutor`?

To bardzo dobry wybór dla operacji I/O, bo podczas oczekiwania na dane z dysku lub sieci wątki mogą przełączać się między zadaniami i lepiej wykorzystywać czas programu.

## Kiedy `ProcessPoolExecutor`?

Gdy problem jest **CPU-bound**, np. ciężkie obliczenia numeryczne, przetwarzanie obrazów, duże parsowanie lub analiza wymagająca intensywnego użycia procesora.
