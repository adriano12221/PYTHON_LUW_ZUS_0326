"""registry.py

Centralny rejestr analizatorów oraz metaklasa odpowiedzialna za
ich automatyczne wykrywanie i rejestrację.
"""

from __future__ import annotations

from abc import ABCMeta
from typing import Dict, Type


class UnsupportedFileTypeError(Exception):
    """Błąd zgłaszany, gdy dla rozszerzenia nie ma analizatora."""


class AnalyzerRegistrationError(TypeError):
    """Błąd zgłaszany, gdy klasa analizatora jest niepoprawna."""


class AnalyzerRegistry:
    """Globalny rejestr analizatorów.

    Przechowuje mapowanie:
        rozszerzenie pliku -> klasa analizatora

    Dzięki temu silnik analizy może dynamicznie dobrać odpowiednią klasę
    bez używania wielu instrukcji if/elif.
    """

    _registry: Dict[str, Type["FileAnalyzer"]] = {}

    @classmethod
    def register(cls, analyzer_cls: Type["FileAnalyzer"]) -> None:
        """Rejestruje klasę analizatora dla wskazanego rozszerzenia."""
        extension = getattr(analyzer_cls, "extension", None)

        # Klasa bazowa może nie mieć rozszerzenia. Pomijamy ją.
        if not extension:
            return

        normalized = extension.lower().strip()
        cls._registry[normalized] = analyzer_cls

    @classmethod
    def get_analyzer_class(cls, extension: str) -> Type["FileAnalyzer"]:
        """Zwraca klasę analizatora na podstawie rozszerzenia."""
        normalized = extension.lower().strip()
        if normalized not in cls._registry:
            raise UnsupportedFileTypeError(
                f"Brak analizatora dla rozszerzenia: {normalized}"
            )
        return cls._registry[normalized]

    @classmethod
    def all_analyzers(cls) -> Dict[str, Type["FileAnalyzer"]]:
        """Zwraca kopię całego rejestru analizatorów."""
        return dict(cls._registry)


class AnalyzerMeta(ABCMeta):
    """Metaklasa automatycznie rejestrująca klasy analizatorów.

    Dodatkowo sprawdza, czy konkretna klasa potomna implementuje metodę
    analyze(). Dzięki temu błędy architektoniczne są wykrywane już podczas
    tworzenia klasy, a nie dopiero w czasie działania programu.
    """

    def __new__(mcls, name, bases, namespace, **kwargs):
        cls = super().__new__(mcls, name, bases, namespace, **kwargs)

        # Czy to klasa bazowa? Jeśli tak, nie walidujemy jej jak zwykłego pluginu.
        is_base_class = namespace.get("__abstract__", False)

        if not is_base_class:
            # Konkretny analizator musi definiować analyze().
            analyze = getattr(cls, "analyze", None)
            if analyze is None:
                raise AnalyzerRegistrationError(
                    f"Klasa {name} musi implementować metodę analyze()."
                )

            # extension jest obowiązkowe dla klas konkretnych.
            if not getattr(cls, "extension", None):
                raise AnalyzerRegistrationError(
                    f"Klasa {name} musi posiadać atrybut 'extension'."
                )

            AnalyzerRegistry.register(cls)

        return cls
