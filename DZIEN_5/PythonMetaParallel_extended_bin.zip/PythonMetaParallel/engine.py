"""engine.py

Silnik odpowiedzialny za:
- dobór analizatora na podstawie rozszerzenia
- analizę sekwencyjną i równoległą
- logowanie zdarzeń
- dynamiczne ładowanie pluginów
"""

from __future__ import annotations

import importlib
import logging
import os
import pkgutil
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Iterable, List, Tuple

# Import podstawowych analizatorów jest ważny, bo ich klasy rejestrują się
# w metaklasie już przy imporcie modułu.
import analyzers  # noqa: F401
from registry import AnalyzerRegistry


def configure_logging(log_file: str = "analysis.log") -> None:
    """Konfiguracja logowania do pliku i na konsolę."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(threadName)s | %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(),
        ],
        force=True,
    )


def load_plugins(package_name: str = "plugins") -> None:
    """Dynamicznie importuje wszystkie moduły z katalogu pluginów.

    Dzięki temu można dodawać nowe analizatory bez zmiany engine.py
    ani main.py. Wystarczy utworzyć nowy moduł z klasą analizatora.
    """
    try:
        package = importlib.import_module(package_name)
    except ModuleNotFoundError:
        logging.warning("Nie znaleziono pakietu pluginów: %s", package_name)
        return

    for _, module_name, is_pkg in pkgutil.iter_modules(package.__path__):
        if is_pkg:
            continue
        full_name = f"{package_name}.{module_name}"
        importlib.import_module(full_name)
        logging.info("Załadowano plugin: %s", full_name)


def _analyze_single_file(file_path: str) -> Tuple[str, str]:
    """Analizuje pojedynczy plik i zwraca opisowy wynik.

    Zwracana krotka ma postać:
        (ścieżka_pliku, opis_wyniku)
    """
    extension = os.path.splitext(file_path)[1].lower()
    analyzer_cls = AnalyzerRegistry.get_analyzer_class(extension)
    analyzer = analyzer_cls()

    logging.info("Start analizy: %s", file_path)
    result = analyzer.analyze(file_path)
    logging.info("Koniec analizy: %s", file_path)

    unit = {
        ".txt": "words",
        ".csv": "rows",
        ".json": "elements",
        ".xml": "elements",
        ".log": "lines",
        ",bin": "bytes",
    }.get(extension, "items")

    return file_path, f"{result} {unit}"


def analyze_files_sequential(files: Iterable[str]) -> Tuple[List[Tuple[str, str]], float]:
    """Analiza plików jeden po drugim."""
    start = time.perf_counter()
    results: List[Tuple[str, str]] = []

    for file_path in files:
        try:
            results.append(_analyze_single_file(file_path))
        except Exception as exc:  # noqa: BLE001 - celowo szeroko, edukacyjnie
            logging.exception("Błąd podczas analizy %s", file_path)
            results.append((file_path, f"ERROR: {exc}"))

    duration = time.perf_counter() - start
    return results, duration


def analyze_files_parallel(
    files: Iterable[str], max_workers: int | None = None
) -> Tuple[List[Tuple[str, str]], float]:
    """Analiza plików równolegle z użyciem ThreadPoolExecutor.

    Wyniki są zbierane w kolejności zakończenia zadań, zgodnie z wymaganiem.
    """
    start = time.perf_counter()
    results: List[Tuple[str, str]] = []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_file = {
            executor.submit(_analyze_single_file, file_path): file_path
            for file_path in files
        }

        for future in as_completed(future_to_file):
            file_path = future_to_file[future]
            try:
                results.append(future.result())
            except Exception as exc:  # noqa: BLE001
                logging.exception("Błąd podczas analizy %s", file_path)
                results.append((file_path, f"ERROR: {exc}"))

    duration = time.perf_counter() - start
    return results, duration


def print_summary(title: str, results: List[Tuple[str, str]], duration: float) -> None:
    """Czytelny wydruk podsumowania wyników."""
    print(f"\n{title}")
    print("-" * len(title))
    for file_path, result in results:
        print(f"{file_path} -> {result}")
    print(f"Czas wykonania: {duration:.4f} s")
