"""main.py

Punkt startowy programu demonstracyjnego.
Uruchamia analizę sekwencyjną i równoległą oraz pokazuje rejestr analizatorów.
"""

from __future__ import annotations

from engine import (
    analyze_files_parallel,
    analyze_files_sequential,
    configure_logging,
    load_plugins,
    print_summary,
)
from registry import AnalyzerRegistry


def main() -> None:
    configure_logging()

    # Ładujemy pluginy dynamiczne. Na potrzeby demonstracji w katalogu plugins
    # dodaliśmy przykładowy plugin dla plików .log.
    load_plugins("plugins")

    files = [
        "data/data1.txt",
        "data/data2.txt",
        "data/data3.csv",
        "data/data4.json",
        "data/data5.xml",
        "data/system.log",  # plugin dynamiczny
        "data/unknown.bin",  # pokaże kontrolowany błąd
    ]

    print("Zarejestrowane analizatory:")
    for ext, analyzer_cls in AnalyzerRegistry.all_analyzers().items():
        print(f"  {ext:<6} -> {analyzer_cls.__name__}")

    sequential_results, sequential_time = analyze_files_sequential(files)
    parallel_results, parallel_time = analyze_files_parallel(files, max_workers=4)

    print_summary("WYNIKI SEKWENCYJNE", sequential_results, sequential_time)
    print_summary("WYNIKI RÓWNOLEGŁE", parallel_results, parallel_time)

    if parallel_time > 0:
        speedup = sequential_time / parallel_time
        print(f"\nPrzyspieszenie równoległe: {speedup:.2f}x")


if __name__ == "__main__":
    main()
