from __future__ import annotations

import csv
import json
import logging
import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import paramiko

from quantumdice import QuantumDiceEngine


COMMANDS = ["hostname", "whoami", "uptime", "df -h"]
DEFAULT_TIMEOUT = 10
DEFAULT_WORKERS = 5
BASE_DIR = Path(__file__).resolve().parent
SERVERS_FILE = BASE_DIR / "servers.json"
REPORT_FILE = BASE_DIR / "report.csv"
LOG_FILE = BASE_DIR / "app.log"


def setup_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(threadName)s | %(message)s",
        handlers=[
            logging.FileHandler(LOG_FILE, encoding="utf-8"),
            logging.StreamHandler(),
        ],
    )


def load_servers(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(f"Nie znaleziono pliku: {path}")

    with path.open("r", encoding="utf-8") as file:
        data = json.load(file)

    if not isinstance(data, list):
        raise ValueError("Plik servers.json musi zawierać listę obiektów serwerów.")

    return data


class SSHRunner:
    def __init__(self, commands: list[str], timeout: int = DEFAULT_TIMEOUT) -> None:
        self.commands = commands
        self.timeout = timeout

    def _connect(self, server: dict[str, Any]) -> paramiko.SSHClient:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        connect_kwargs = {
            "hostname": server["host"],
            "port": server.get("port", 22),
            "username": server["username"],
            "timeout": server.get("timeout", self.timeout),
            "banner_timeout": server.get("timeout", self.timeout),
            "auth_timeout": server.get("timeout", self.timeout),
        }

        if server.get("password"):
            connect_kwargs["password"] = server["password"]
        if server.get("key_filename"):
            connect_kwargs["key_filename"] = server["key_filename"]

        client.connect(**connect_kwargs)
        return client

    def _run_command(self, client: paramiko.SSHClient, command: str, timeout: int) -> dict[str, Any]:
        start = time.perf_counter()
        stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
        exit_status = stdout.channel.recv_exit_status()
        duration = round(time.perf_counter() - start, 4)

        output = stdout.read().decode("utf-8", errors="replace").strip()
        error_output = stderr.read().decode("utf-8", errors="replace").strip()

        return {
            "command": command,
            "exit_status": exit_status,
            "duration_s": duration,
            "stdout": output,
            "stderr": error_output,
            "status": "success" if exit_status == 0 else "command_error",
        }

    def execute_on_server(self, server: dict[str, Any]) -> dict[str, Any]:
        alias = server.get("name", server["host"])
        timeout = server.get("timeout", self.timeout)
        logging.info("Start dla serwera: %s", alias)

        result: dict[str, Any] = {
            "server": alias,
            "host": server["host"],
            "status": "success",
            "connection_error": "",
            "commands": [],
            "successful_commands": 0,
            "failed_commands": 0,
        }

        client: paramiko.SSHClient | None = None
        try:
            client = self._connect(server)
            logging.info("Połączono z serwerem: %s", alias)

            for command in self.commands:
                cmd_result = self._run_command(client, command, timeout)
                result["commands"].append(cmd_result)

                if cmd_result["status"] == "success":
                    result["successful_commands"] += 1
                else:
                    result["failed_commands"] += 1
                    result["status"] = "partial_error"

                logging.info(
                    "Serwer=%s | komenda=%s | status=%s | czas=%.4fs",
                    alias,
                    command,
                    cmd_result["status"],
                    cmd_result["duration_s"],
                )

        except (paramiko.AuthenticationException, paramiko.SSHException, socket.timeout, TimeoutError, OSError) as exc:
            result["status"] = "connection_error"
            result["connection_error"] = str(exc)
            logging.exception("Błąd połączenia dla serwera %s: %s", alias, exc)
        finally:
            if client is not None:
                client.close()
                logging.info("Zamknięto połączenie z serwerem: %s", alias)

        return result


def flatten_results(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []

    for server_result in results:
        if not server_result["commands"]:
            rows.append(
                {
                    "server": server_result["server"],
                    "host": server_result["host"],
                    "server_status": server_result["status"],
                    "command": "",
                    "command_status": "",
                    "exit_status": "",
                    "duration_s": "",
                    "stdout": "",
                    "stderr": "",
                    "connection_error": server_result["connection_error"],
                }
            )
            continue

        for command_result in server_result["commands"]:
            rows.append(
                {
                    "server": server_result["server"],
                    "host": server_result["host"],
                    "server_status": server_result["status"],
                    "command": command_result["command"],
                    "command_status": command_result["status"],
                    "exit_status": command_result["exit_status"],
                    "duration_s": command_result["duration_s"],
                    "stdout": command_result["stdout"],
                    "stderr": command_result["stderr"],
                    "connection_error": server_result["connection_error"],
                }
            )

    return rows


def save_report(path: Path, rows: list[dict[str, Any]]) -> None:
    fieldnames = [
        "server",
        "host",
        "server_status",
        "command",
        "command_status",
        "exit_status",
        "duration_s",
        "stdout",
        "stderr",
        "connection_error",
    ]

    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def summarize(results: list[dict[str, Any]]) -> dict[str, int]:
    summary = {
        "servers_total": len(results),
        "servers_success": 0,
        "servers_with_errors": 0,
        "commands_success": 0,
        "commands_failed": 0,
    }

    for item in results:
        if item["status"] == "success":
            summary["servers_success"] += 1
        else:
            summary["servers_with_errors"] += 1

        summary["commands_success"] += item["successful_commands"]
        summary["commands_failed"] += item["failed_commands"]

    return summary


def main() -> None:
    setup_logging()
    logging.info("Uruchomienie SSH Multi-Server Runner")

    servers = load_servers(SERVERS_FILE)
    dice = QuantumDiceEngine()
    prioritized_servers = dice.prioritize(servers)

    logging.info("Kolejność serwerów po QuantumDice:")
    for server in prioritized_servers:
        logging.info(
            "  %s (%s) | quantum_score=%.4f | strategy=%s",
            server.get("name", server["host"]),
            server["host"],
            server["quantum_score"],
            server["quantum_strategy"],
        )

    runner = SSHRunner(COMMANDS)
    results: list[dict[str, Any]] = []

    max_workers = min(DEFAULT_WORKERS, len(prioritized_servers)) or 1
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {
            executor.submit(runner.execute_on_server, server): server for server in prioritized_servers
        }

        for future in as_completed(future_map):
            server = future_map[future]
            try:
                server_result = future.result()
                enriched = dice.annotate_result(server, server_result)
                results.append(enriched)
            except Exception as exc:  # noqa: BLE001
                alias = server.get("name", server["host"])
                logging.exception("Nieobsłużony wyjątek dla %s: %s", alias, exc)
                results.append(
                    {
                        "server": alias,
                        "host": server["host"],
                        "status": "internal_error",
                        "connection_error": str(exc),
                        "commands": [],
                        "successful_commands": 0,
                        "failed_commands": 0,
                        "quantum_score": server.get("quantum_score", 0.0),
                        "quantum_strategy": server.get("quantum_strategy", "unknown"),
                        "quantum_verdict": "unstable",
                    }
                )

    rows = flatten_results(results)
    save_report(REPORT_FILE, rows)
    summary = summarize(results)

    logging.info("Zapisano raport do %s", REPORT_FILE)
    logging.info("Podsumowanie: %s", summary)

    print("\n=== PODSUMOWANIE ===")
    for key, value in summary.items():
        print(f"{key}: {value}")
    print(f"report.csv: {REPORT_FILE}")
    print(f"app.log: {LOG_FILE}")


if __name__ == "__main__":
    main()
