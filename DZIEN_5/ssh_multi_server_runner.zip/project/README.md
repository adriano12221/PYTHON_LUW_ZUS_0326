# SSH Multi-Server Runner + QuantumDice

Projekt wykonuje równoległe połączenia SSH do wielu serwerów, uruchamia komendy administracyjne i zapisuje raport CSV.

## Funkcje

- wczytywanie serwerów z `servers.json`
- połączenia SSH przez `paramiko`
- równoległe wykonanie przez `ThreadPoolExecutor`
- obsługa błędów połączenia i timeoutów
- zapis wyników do `report.csv`
- logowanie do `app.log`
- pomiar czasu wykonania każdej komendy
- podsumowanie sukcesów i błędów
- warstwa priorytetyzacji `QuantumDice`

## Instalacja

```bash
pip install -r requirements.txt
```

## Uruchomienie

```bash
python main.py
```

## Struktura `servers.json`

Każdy serwer może mieć pola:

- `name`
- `host`
- `port`
- `username`
- `password` lub `key_filename`
- `timeout`
- `criticality`
- `expected_latency`
- `instability`
- `business_weight`

Ostatnie cztery pola są używane przez uproszczony silnik `QuantumDiceEngine`, który ustala kolejność przetwarzania serwerów.

## Jak działa QuantumDice tutaj

To nie jest pełna wersja Twojego paradygmatu. Tu działa jako lekka warstwa decyzyjna:

1. ocenia serwer przed wykonaniem,
2. ustala strategię (`rush-first`, `balanced`, `safe-probe`),
3. po wykonaniu dopina werdykt (`stable`, `watch`, `unstable`).

To daje bardzo sensowny fundament do dalszej rozbudowy o historię uruchomień, retry policy, anomaly scoring albo adaptację parametrów.
