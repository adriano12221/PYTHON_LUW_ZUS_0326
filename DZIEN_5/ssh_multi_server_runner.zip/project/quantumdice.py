from __future__ import annotations

import hashlib
from copy import deepcopy
from typing import Any


class QuantumDiceEngine:
    """
    Uproszczona warstwa decyzyjna inspirowana ideą QuantumDice.

    Co robi:
    1. Nadaje priorytet serwerom przed uruchomieniem.
    2. Łączy heurystykę biznesową z lekkim składnikiem eksploracji.
    3. Ocenia wynik końcowy serwera jako stable / watch / unstable.

    Możesz rozbudować ją później o historię z poprzednich uruchomień,
    samouczenie lub zapisywanie metryk w osobnym magazynie.
    """

    def prioritize(self, servers: list[dict[str, Any]]) -> list[dict[str, Any]]:
        enriched: list[dict[str, Any]] = []

        for server in servers:
            item = deepcopy(server)
            score, strategy = self._score_server(item)
            item["quantum_score"] = score
            item["quantum_strategy"] = strategy
            enriched.append(item)

        enriched.sort(key=lambda s: s["quantum_score"], reverse=True)
        return enriched

    def annotate_result(self, server: dict[str, Any], result: dict[str, Any]) -> dict[str, Any]:
        result["quantum_score"] = server.get("quantum_score", 0.0)
        result["quantum_strategy"] = server.get("quantum_strategy", "standard")

        if result["status"] == "success" and result["failed_commands"] == 0:
            verdict = "stable"
        elif result["status"] in {"partial_error", "success"}:
            verdict = "watch"
        else:
            verdict = "unstable"

        result["quantum_verdict"] = verdict
        return result

    def _score_server(self, server: dict[str, Any]) -> tuple[float, str]:
        criticality = float(server.get("criticality", 0.5))
        expected_latency = float(server.get("expected_latency", 0.5))
        instability = float(server.get("instability", 0.5))
        business_weight = float(server.get("business_weight", 0.5))

        exploration = self._deterministic_noise(
            f"{server.get('host')}|{server.get('username')}|{server.get('name', '')}"
        )

        score = (
            criticality * 0.40
            + business_weight * 0.30
            + (1.0 - expected_latency) * 0.20
            + (1.0 - instability) * 0.10
            + exploration * 0.05
        )

        if score >= 0.80:
            strategy = "rush-first"
        elif score >= 0.60:
            strategy = "balanced"
        else:
            strategy = "safe-probe"

        return round(score, 4), strategy

    def _deterministic_noise(self, seed_text: str) -> float:
        digest = hashlib.sha256(seed_text.encode("utf-8")).hexdigest()
        chunk = digest[:8]
        return int(chunk, 16) / 0xFFFFFFFF
